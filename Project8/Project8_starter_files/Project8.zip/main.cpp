#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "Parse.h"
#include "Project8.h"
using namespace std;

int main(void) {
    set_input("test_grader.blip");
    run();
}
