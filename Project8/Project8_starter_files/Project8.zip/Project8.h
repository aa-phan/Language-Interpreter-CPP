//
// Created by Aaron on 11/23/2023.
//

#ifndef PROJECT8_STARTER_FILES_PROJECT8_H
#define PROJECT8_STARTER_FILES_PROJECT8_H
#include <iostream>
#include <map>
#include <vector>
#include <stdlib.h>
#include <stdio.h>
#include "Parse.h"
using namespace std;
void run();
void blipGen();
int polishExp(vector<string>& input);
void initVar();
void setVar();
int operations(string op, int a, int b);

#endif //PROJECT8_STARTER_FILES_PROJECT8_H
